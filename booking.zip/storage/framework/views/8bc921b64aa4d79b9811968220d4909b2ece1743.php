<?php $__env->startSection('content'); ?>
<div id="content">
    <div id="content-header">
        <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Addons pages</a> <a href="#" class="current">invoice</a> 
        </div>
        <h1>My Invoices</h1>
    </div>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="container-fluid"><hr>
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"> <i class="icon-briefcase"></i> </span>
                        <h5 >Invoice</h5>
                    </div>
                    <div class="widget-content">
                        <div class="row-fluid">
                            <div class="span6">
                                <table class="">
                                    <tbody>
                                        <tr>
                                            <td><h4><?php echo e($company_settings->name); ?></h4></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($company_settings->adress); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($company_settings->town); ?> &nbsp; - &nbsp;<?php echo e($company_settings->code); ?></td>
                                        </tr>
                                        <tr>
                                            <td><?php echo e($company_settings->telephone); ?></td>
                                        </tr>
                                        <tr>
                                            <td ><?php echo e($company_settings->email); ?> <br>
                                            <?php echo e($company_settings->website); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="span6">
                                <table class="table table-bordered table-invoice">
                                    <tbody>
                                        <tr>
                                        <tr>
                                            <td class="width30">Invoice ID:</td>
                                            <td class="width70"><strong><?php echo e($product->invoice); ?></strong></td>
                                        </tr>
                                        <tr>
                                            <td>Issue Date:</td>
                                            <td><strong><?php echo e($product->startdatetime); ?></strong></td>
                                        </tr>
                                        <tr>
                                            <td>Due Date:</td>
                                            <td><strong><?php echo e($product->enddatetime); ?></strong></td>
                                        </tr>
                                    <td class="width30">Client Address:</td>
                                    <td class="width70"><strong><?php echo e(Auth::user()->full_name); ?></strong> <br>
                                        <?php echo e($product->adress); ?><br>
                                        <?php echo e($product->town); ?> &nbsp; <?php echo e($product->county); ?> &nbsp; County <br>
                                        Contact No: <?php echo e(Auth::user()->telephone); ?> <br>
                                        Email: <?php echo e(Auth::user()->email); ?> </td>
                                    </tr>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                        <div class="row-fluid">
                            <div class="span12">
                                <table class="table table-bordered table-invoice-full">
                                    <thead>
                                        <tr>
                                            <th class="head0">Type</th>
                                            <th class="head1">Desc</th>
                                            <th class="head0 right">Qty</th>
                                            <th class="head1 right">Price</th>
                                            <th class="head0 right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($product->s_name); ?></td>
                                            <td> </td>
                                            <td class="right">1</td>
                                            <td class="right">Ksh &nbsp;<?php echo e($product->amount); ?></td>

                                            <td class="right"><strong>Ksh &nbsp;<?php echo e($product->amount); ?></strong></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table class="table table-bordered table-invoice-full">
                                    <tbody>
                                        <tr>
                                            <td class="msg-invoice" width="75%"><h4>Payment method: </h4>
                                                <a href="#" class="tip-bottom" title="Wire Transfer">Cash in hand</a> |  <a href="#" class="tip-bottom" title="Bank account">Bank account #</a> |  <a href="#" class="tip-bottom" title="SWIFT code">Mpesa </a>|  <a href="#" class="tip-bottom" title="IBAN Billing address">Cheque </a></td>
                                            <td class="right"><strong>Subtotal</strong> <br>
                                                <strong>Tax ( <?php echo e($product->tax*100); ?>%)</strong> <br>
                                                <strong>Discount</strong></td>
                                            <td class="right"><strong>Ksh &nbsp;<?php echo e($product->amount); ?> <br>
                                                    Ksh &nbsp;<?php echo e($product->amount*$product->tax); ?><br>
                                                    ksh <?php echo e($product->discount); ?></strong></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="pull-right">
                                    <h4><span>Amount Due:</span>Ksh &nbsp;<?php echo e($product->total - $product->discount); ?></h4>
                                    <br>
                                    <?php if($product->name== 'Unpaid'): ?>
                                    <a class="btn btn-danger btn-large pull-right" href="<?php echo e(url('client/make_payment/'.$product->id)); ?>">Pay Invoice</a> </div>
                                <?php else: ?>
                                <a class="btn btn-success btn-large pull-right" href="">Paid</a> </div>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<!--/div-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clientLayout.client_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\booking\resources\views/client/payment/invoices.blade.php */ ?>