<div class="row-fluid">
  <div id="footer" class="span12"> 2019 &copy; Booking. Powered by <a href="https://otemainc.com">Otema</a> </div>
</div>
<?php /* C:\xampp\htdocs\booking\resources\views/layouts/clientLayout/client_footer.blade.php */ ?>