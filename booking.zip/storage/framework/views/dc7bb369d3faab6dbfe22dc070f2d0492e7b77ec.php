<?php $__env->startSection('content'); ?>
<div id="content">
    <div id="content-header">
        <div id="breadcrumb"> <a href="<?php echo e(url('admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> 
            <a href="<?php echo e(url('admin/view_services')); ?>">Services</a> <a href="#" class="current">Edit Services</a> 
        </div>
        <h1>Edit Services</h1>
    </div>
    <div class="container-fluid"><hr>
        <?php if(Session::has('flash_message_error')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_error'); ?></strong>
        </div>
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_success'); ?></strong>
        </div>
        <?php endif; ?>
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
                        <h5>Edit Service Form</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <form class="form-horizontal" method="post" action="<?php echo e(url('admin/edit_service/'.$services->id)); ?>" name="edit_account" id="edit_account" novalidate="novalidate"><?php echo e(csrf_field()); ?>

                            <div class="control-group">
                                <label class="control-label">Service Name</label>
                                <div class="controls">
                                    <input type="text" name="product_name" id="product_name" value="<?php echo e($services->s_name); ?>">
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Parent Service</label>
                                <div class="controls">
                                    <select name="category_id" style="width: 220px;">
                                        <option value="0">Parent</option>
                                        <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($level->id); ?>" <?php if($level->id == $services->parent_id): ?>
                                                selected <?php endif; ?>><?php echo e($level->s_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Description</label>
                                <div class="controls">
                                    <input type="text" name="product_town" id="product_town" value="<?php echo e($services->description); ?>">                             
                                </div>
                            </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" value="Save" class="btn btn-success">
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\booking\resources\views/admin/service/edit_service.blade.php */ ?>