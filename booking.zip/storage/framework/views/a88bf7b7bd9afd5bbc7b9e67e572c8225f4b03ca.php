<?php $__env->startSection('content'); ?>
<div id="content">
    <div id="content-header">
        <div id="breadcrumb"> <a href="<?php echo e(url('admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> 
            <a href="#">Clients</a> <a href="#" class="current">View Clients</a> 
        </div>
        <h1>View Sessions</h1>
    </div>
    <div class="container-fluid"><hr>
        <?php if(Session::has('flash_message_error')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_error'); ?></strong>
        </div>
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_success'); ?></strong>
        </div>
        <?php endif; ?>
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                        <h5>Sessions</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>CLIENT NAME</th>
                                    <th>EMAIL</th>
                                    <th>TELEPHONE</th>
                                    <th>ADDRESS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $allclients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gradeX">
                                    <td class="text-center"><?php echo e($client->id); ?></td>
                                    <td class="text-center"><?php echo e($client->full_name); ?></td>
                                    <td class="text-center"><?php echo e($client->email); ?></td>
                                    <td class="text-center"><?php echo e($client->telephone); ?></td>
                                    <td class="text-center"><?php echo e($client->contact_adress); ?></td>
                                    <td><a href="#productModal<?php echo e($client->id); ?>" data-toggle="modal" class="btn btn-success btn-mini">View <i class="icon icon-eye-open"></i></a> | 
                                        <a rel="<?php echo e($client->id); ?>" rel1="delete_client" href="javascript:" class="btn btn-danger btn-mini deleteClient">Delete <i class="icon icon-trash"></i></a></td>
                                </tr>
                            <div id="productModal<?php echo e($client->id); ?>" class="modal hide">
                                <div class="modal-header bg-blue-dark">
                                    <button data-dismiss="modal" class="close" type="button">×</button>
                                    <h3 class="text-center">NAME: <?php echo e($client->full_name); ?></h3>
                                </div>
                                <div class="modal-body">
                                    <p class="text-center">EMAIL: ><?php echo e($client->email); ?></p>
                                    <p class="text-center bg-primary">TELEPHONE: <?php echo e($client->telephone); ?></p>
                                    <p class="text-center">ADDRESS: <?php echo e($client->contact_address); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\booking\resources\views/admin/client/view_clients.blade.php */ ?>