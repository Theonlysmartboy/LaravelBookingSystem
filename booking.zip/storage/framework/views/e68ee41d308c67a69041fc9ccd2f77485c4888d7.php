<?php $__env->startSection('content'); ?>
<div id="content">
    <div id="content-header">
        <div id="breadcrumb"> <a href="<?php echo e(url('admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> 
            <a href="#">Sessions</a> <a href="#" class="current">View Sessions</a> 
        </div>
        <h1>View Sessions</h1>
    </div>
    <div class="container-fluid"><hr>
        <?php if(Session::has('flash_message_error')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_error'); ?></strong>
        </div>
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_success'); ?></strong>
        </div>
        <?php endif; ?>
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                        <h5>Sessions</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>CLIENT</th>
                                    <th>Service</th>
                                    <th>START DATE</th>
                                    <th>END DATE</th>
                                    <th>LOCATION</th>
                                    <th>COST</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gradeX">
                                    <td class="text-center"><?php echo e($product->id); ?></td>
                                    <td class="text-center"><?php echo e($product->uname); ?></td>
                                    <td class="text-center"><?php echo e($product->s_name); ?></td>
                                    <td class="text-center"><?php echo e($product->startdatetime); ?></td>
                                    <td class="text-center"><?php echo e($product->enddatetime); ?></td>
                                    <td class="text-center"><?php echo e($product->town); ?> &nbsp; <?php echo e($product->county); ?> &nbsp; County</td>
                                    <td class="text-center">Ksh &nbsp;<?php echo e($product->total); ?></td>
                                    <td class="text-center">
                                        <?php echo e($product->name); ?>

                                    </td>
                                    <td><a href="#productModal<?php echo e($product->id); ?>" data-toggle="modal" class="btn btn-success btn-mini">View <i class="icon icon-eye-open"></i></a> | 
                                        <?php if($product->status==1): ?>
                                        <a href="<?php echo e(url('admin/accept_booking/'.$product->id)); ?>" class="btn btn-primary btn-mini">Accept <i class="icon icon-edit"></i></a> | 
                                        <a href="<?php echo e(url('admin/reject_booking/'.$product->id)); ?>" class="btn btn-warning btn-mini">Reject <i class="icon icon-edit"></i></a> | 
                                        <?php endif; ?>
                                        <a rel="<?php echo e($product->id); ?>" rel1="delete_booking" href="javascript:" class="btn btn-danger btn-mini deleteBooking">Delete <i class="icon icon-trash"></i></a></td>
                                </tr>
                            <div id="productModal<?php echo e($product->id); ?>" class="modal hide">
                                <div class="modal-header bg-blue-dark">
                                    <button data-dismiss="modal" class="close" type="button">×</button>
                                    <h3 class="text-center">Session: <?php echo e($product->s_name); ?></h3>
                                </div>
                                <div class="modal-body">
                                    <p class="text-center">START: ><?php echo e($product->startdatetime); ?></p>
                                    <p class="text-center bg-primary">END: <?php echo e($product->enddatetime); ?></p>
                                    <p class="text-center">LOCATION: <?php echo e($product->town); ?> &nbsp; <?php echo e($product->county); ?> &nbsp; County</p>
                                    <p class="text-center">PRICE: Ksh &nbsp;<?php echo e($product->total); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\booking\resources\views/admin/booking/view_bookings.blade.php */ ?>