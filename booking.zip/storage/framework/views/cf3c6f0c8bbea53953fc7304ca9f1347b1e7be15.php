<?php $__env->startSection('content'); ?>
<div id="content">
    <div id="content-header">
        <div id="breadcrumb"> <a href="<?php echo e(url('admin/dashboard')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> 
            <a href="<?php echo e(url('admin/add_bank_details')); ?>" >Add Accounts</a> <a href="" class="current">View Accounts</a>
        </div>
        <h1>View Bank Accounts</h1>
    </div>
    <div class="container-fluid"><hr>
        <?php if(Session::has('flash_message_error')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_error'); ?></strong>
        </div>
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>	
            <strong><?php echo session('flash_message_success'); ?></strong>
        </div>
        <?php endif; ?>
        <div class="row-fluid">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                        <h5>Accounts</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>BANK</th>
                                    <th>BRANCH</th>
                                    <th>ACCOUNT NAME</th>
                                    <th>ACCOUNT NO</th>
                                    <th>PAYBILL NO</th>
                                    <th>STATUS</th>
                                    <th>ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $banksettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gradeX">
                                    <td class="text-center"><?php echo e($setting->id); ?></td>
                                    <td class="text-center"><?php echo e($setting->bank); ?></td>
                                    <td class="text-center"><?php echo e($setting->branch); ?></td>
                                    <td class="text-center"><?php echo e($setting->name); ?></td>
                                    <td class="text-center"><?php echo e($setting->account_no); ?></td>
                                    <td class="text-center"><?php echo e($setting->paybill_no); ?></td>
                                    <td class="text-center">
                                        <?php if($setting->is_current == 1): ?>
                                        Active
                                        <?php else: ?>
                                        Not active
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="#productModal<?php echo e($setting->id); ?>" data-toggle="modal" class="btn btn-success btn-mini">View <i class="icon icon-eye-open"></i></a> | 
                                        <a href="<?php echo e(url('admin/edit_bank_details/'.$setting->id)); ?>" class="btn btn-primary btn-mini">Edit <i class="icon icon-edit"></i></a> | 
                                        <?php if($setting->is_current == 2): ?>
                                        <a href="<?php echo e(url('admin/enable/'.$setting->id)); ?>" class="btn btn-warning btn-mini">Activate <i class="icon icon-edit"></i></a>
                                        <?php else: ?>
                                        <a href="<?php echo e(url('admin/disable/'.$setting->id)); ?>" class="btn btn-warning btn-mini">Disable <i class="icon icon-edit"></i></a>
                                        <?php endif; ?>
                                        <a rel="<?php echo e($setting->id); ?>" rel1="delete_bank_details" href="javascript:" class="btn btn-danger btn-mini deleteAccount">Delete <i class="icon icon-trash"></i></a></td>
                                </tr>
                            <div id="productModal<?php echo e($setting->id); ?>" class="modal hide">
                                <div class="modal-header bg-blue-dark">
                                    <button data-dismiss="modal" class="close" type="button">×</button>
                                    <h3 class="text-center">Session: <?php echo e($setting->service_name); ?></h3>
                                </div>
                                <div class="modal-body">
                                    <p class="text-center">START: ><?php echo e($setting->startdatetime); ?></p>
                                    <p class="text-center bg-primary">END: <?php echo e($setting->enddatetime); ?></p>
                                    <p class="text-center">LOCATION: <?php echo e($setting->town); ?> &nbsp; <?php echo e($setting->county); ?> &nbsp; County</p>
                                    <p class="text-center">PRICE: Ksh &nbsp;<?php echo e($setting->service_fee); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\booking\resources\views/admin/company/view_bank_details.blade.php */ ?>