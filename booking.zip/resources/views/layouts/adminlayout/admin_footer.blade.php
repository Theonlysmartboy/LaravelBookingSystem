<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; Smart Farmer. Powered by <a href="https://otemainc.com">Otema</a> </div>
</div>